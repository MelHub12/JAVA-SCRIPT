/* js8 Unicode Stars
*/

// User prompt
var lines = parseInt(prompt('Please enter the number of lines to display'));

//Main loop
for (var i = 1; i < lines + 1; i++)
{
  document.write('<span class="lineNum">' + i + ' .   </span>');
  for (var j = 0; j < i; j++)
  {
    // Alternate star color
    if (j % 2)
    {
      var starClass = 'odd';
    }
    else
     {
       var starClass = 'even';
    }

    document.write('<span class="' + starClass + '">&#x2605;</span>');
  }

  document.write('<br>');
}
