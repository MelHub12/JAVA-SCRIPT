//Style sheet for js3

var arrColors = new Array();

//Array of colors
arrColors[0] = '#ff0000';
arrColors[1] = '#123456';
arrColors[2] = '#e2e233';
arrColors[3] = '#f04477';
arrColors[4] = '#2288ad';

//Get index
var color = parseInt(prompt('We have ' + arrColors.length + 'colors available to pick from. \nPlease choose a number from 0 to ' + parseInt(arrcolors.length - 1)));


//Apply color to body element
document.body.style.background = arrColors[color];
