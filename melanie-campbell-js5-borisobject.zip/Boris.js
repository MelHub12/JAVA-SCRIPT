//js5 Boris the Butcher

function Butcher(name, occupation, height, weight, pigCount, huntMode, moodColor)
{
  //Properties
  this.name = name;
  this.occupation = occupation;
  this.height = height;
  this.weight = weight;
  this.pigCount = pigCount;
  this.huntMode = huntMode;
  this.moodColor = moodColor;

  //Method
  this.getName = function()
  {
    return this.name;
  }
}

var boris = new Butcher('Boris', 'Butcher', 8, 300, 1000, false, '#aaf44280');

var e = document.getElementById('container');


document.getElementById('name').textContent += boris.name;
document.getElementById('occupation').textContent += boris.occupation;
document.getElementById('height').textContent += boris.height + 'ft';
document.getElementById('weight').textContent += boris.weight + 'lbs';
document.getElementById('pigCount').textContent += boris.pigCount + 'little ppies met their maker';
document.getElementById('huntMode').textContent += boris.huntMode;
document.getElementById('moodColor').textContent += boris.moodColor;

//Set body background color
e.style.background = boris.moodColor;
