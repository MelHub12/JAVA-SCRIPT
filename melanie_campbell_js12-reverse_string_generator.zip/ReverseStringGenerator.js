/* js12 Reverse String Generator
*/

//Dom Query
var goButton = document.getElementById('goButton');
var inputBox = document.getElementById('input');
var outputBox = document.getElementById('output');
var error = document.getElementById('error');

//Give input focus
inputBox.focus();

//Regular expression pattern
var allowedChars = /^[A-Za-z0-9 .!,"]+$/;

//Set goButton to disables by default
//goButton.disabled = true;

//Go Button
goButton.addEventListener('click', function() {
  go();
});

//Do something whe Go button is clicked or enter is pressed
function go()
{
  var plainText = inputBox.value;
  if (checkChar(plainText)) // Additional check after submission
  {
    var cipherText = reverseText(plainText);
    outputBox.value = cipherText; // Show the output
  }
  else
      setError();
  }

//Handle keyboard
inputBox.addEventListener('keyup', function(event) {
  // Set Go! button state
  setGoButton();

  //Check error
  checkError();

  //Enter key
  var key = event.keyCode;
  if (inputBox.value != '' && key === 13)
    go();
});

//Set the state of the Go! button
function setGoButton()
{
  if (inputBox.value.length > 0 && checkChar(inputBox.value) != null)
    goButton.disabled = false;
  else
    goButton.disabled = true;
}

// Set the error fieldset
function checkError()
{
    if (inputBox.value.length > 0 && checkChar(inputBox.value) == null)
    {
      error.innerHTML = '<img src="img/error.png"> Invalid character detected.';
    }
    else
    {
    error.innerHTML = ' ';
    }
}

//Check for allowed characters
//Returns null if wrong character is detected
function checkChar(c)
{
  return c.match(allowedChars);
}

//Reverse String
function reverseText(str)
{
  var result = '';
  for (var index = str.length - 1; index >= 0; index--)
      result += str.charAt(index);

      return result;
}
