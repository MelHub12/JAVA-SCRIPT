//Code for Area of Circle

//calculate area of a circle
function calcCircleArea(x)
{
  console.log('Calculating circle  ara using radius: ' + x);
  var area = Math.PI * Math.pow(x, 2); // circle area
  return area;
}

//script execution begins
var radius = parseInt(prompt("Calculating area of circle. \nPlease enter the circle's radius"));

document.write('Area of circle using radius ' + radius  + ': ' + calcCircleArea(radius));
