//js4 for Calculate X

//calculate X
var num = parseInt(prompt('Please enter a number: '));


//Num to 1
var xto1 = function(x)
{
  console.log('xto2: ' + x);
  return x;
};

//Square number
var xto2 = function(x)
{
  console.log('xto2: ' + x);
  return Math.pow(x, 2);
};

//Cube num
var xto1 = function(x)
{
  console.log('xto3: ' + x);
  return  x * x * x;
};

//Sum
var sum = function(x)
{
  console.log('sum: ' + x);
  return xto1(x) + xto2(x) + xto3(x);
};


var e = document.getElementById('result');
e. textContent = xto1(num) + '    ' + xto2(num) + '     ' + xto3(num) + '       ' + sum(num);
