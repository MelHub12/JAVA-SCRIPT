/*

*/

var e = document.getElementById('treasure');

document.write('Searching for treasure...<br>');
if(e)
{
  document.write('You Found the Treasure!');
  document.body.style.background = 'Lime';
}
else 
  {
    document.write('Treasure not found. Keep Searching.!');
    document.body.style.background = 'red';
  }
