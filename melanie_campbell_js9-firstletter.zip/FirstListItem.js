//

//DOM Query

var nodelist = document.getElementsByTagName('ul');

// nodelist must be 1 or greater
if(nodelist.length >= 1)
{
  for (var i = 0; i < nodelist.length; i++)
  {
    var items = nodelist[i].getElementsByTagName('li');
    if (items.length >= 1)
    {
      items[0].className = 'firstItem' ;
    }
  }
}
