/* js11 alternating images*/

// image array
var arrImage = [
  'tux1.png',
  'tux2.png',
  'tux3.png',
  'tux4.png',
  'tux5.png'
];

//Get top image element
var topImage = document.getElementById('topImage');

//Gaet all li elements on topImage
var nodelist = document.getElementsByTagName('li');

function showImages()
{
  //Pick top image at random. Avoid sequential duplicates
  var topIndex = 0;
  do {
    topIndex = Math.floor(Math.random() * arrImage.length);
  } while(arrImage[topIndex] == topImage.src.replace(/^.*[\\\/]/, ''));

  topImg = arrImage[topIndex];

  //Pick first image at random
  var indexOne = Math.floor(Math.random() * arrImage.length);

  //Pick second image at random
  var indexTwo = 0;
  do {
    //Avoid a duplicate second images
    indexTwo = Math.floor(Math.random() * arrImage.length);
  } while (indexTwo == indexOne);

  console.log('Top Image: ' + arrImage[topIndex] + ', Image1: ' + arrImage[indexOne] + ', ' + 'Image2: ' + arrImage[indexTwo]);

  //Change top image
  console.log(topImage.src);
  topImage.src = topImg;
  topImage.alt = arrImage[topIndex];

  //Change all li Images
  var toggle = true;
  for (var i = 0; i < nodelist.length; i++)
  {
    var existingImg = nodelist[i].getElementsByTagName('img'); // Dynamic nodelist
    if (existingImg.length > 0)
    existingImg[0].remove();

    //Get existing content
    var content = nodelist[i].innerHTML;

    if(toggle)
      nodelist[i].innerHTML = '<img src=" ' + arrImage[indexOne] + '" alt="' +
      arrImage[indexOne] + '">' + content; // Place image before li content
    else
      nodelist[i].innerHTML = '<img src="' + arrImage[indexTwo] + '" alt="' +
      arrImage[indexOne] + '">' + content; // Place image before li content
      toggle = !toggle;
  }

//Alternate techique using insertAdjacentHTML

}
setInterval(showImages, 1000);
