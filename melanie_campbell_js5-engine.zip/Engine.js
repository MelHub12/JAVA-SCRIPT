//js5 Engine Object

//Engine Object
var engine  = {

  //Properties
  running: false,
  leaking: false,
  model: 'Model T V1',

//Methods
  start: function() {
    this.running = true;
  },
  //Is engine running
  isrunning; function() {
    return this.running;
  },

  // what is the engine NamegetModel: function() {
  getModel: function() {
    return this.model;
  },

  // turn on the Engine
  engine start

};

var e = document.getElentaryById('engine');
e.textContent =  '-------------Engine-------------- '\n\n;


e.textContent += '  Model: ' + engine.getModel() + '\n';
e.textContent += 'Running: ' + engine.isRunning() + '\n';
e.textContent += 'Leaking: ' + engine.leaking() + '\n\n';

e.textContent += '--------------------------------- ';
