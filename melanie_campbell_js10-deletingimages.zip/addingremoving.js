/*Display five images, wait, and then delete them. */
/*Array of images to add */
var arrImg = [
    '01.png',
    '02.png',
    '03.png',
    '04.png',
    '05.png'
];
console.log ('start');
var remover;
//Get the parent element
var e = document.querySelector('body ul');

//Get last count - 1 to count backwards to stop.
var imgCount = arrImg.length - 1;

/* Add image
*/

function addImages()
{
  /*
  img element adds image to page:

  <img src="file_path.ext">
  */

  for (var i = 0; i < arrImg.length; i++)
  {
    //Get the image filename from Array
  var imageName =  arrImg[i];

  //li node
  var newElement = document.createElement('li');

  //img node
  var newImage = document.createElement('img');
  newImage.src = 'img/' + imageName; // image url

console.log('Adding image: ' + newImage.src);

// div node == shows filename
var newDiv = document.createElement('div');

//Add the elements to the li element
newElement.appendChild(newImage);
newElement.appendChild(newDiv).appendChild(document.createTextNode(imageName));

//Add the li child to the ul parent
e.appendChild(newElement);


}
}

//Get all images
var nodelist = document.getElementsByTagName('li');
function removeImage()
{
  // Remove image or button?
  if (nodelist.length > 0)
  {
    console.log('Removing image.');
    e.removeChild(e.firstChild);

    if(nodelist.length == 0)
    {
      var body = document.querySelector('body');
      body.removeChild(button);

      var newMsg = document.createElement('p');
      newMsg.appendChild(document.createTextNode("That's all, folk!"));
      body.appendChild(newMsg);
    }
  }
}


addImages();

var button = document.getElementById('button');
button.addEventListener('click', removeImage);
